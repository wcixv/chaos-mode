CHAOS MODE - BepInEx version (optional)
=======================================
Use this ONLY if you want Chaos Mode next to other BepInEx mods. If you just want Chaos Mode, ignore this
folder and follow the normal install in the main README.txt.

This is the same mod as the normal version, started by BepInEx instead of the built-in mod loader.

SETUP (once)
This game needs BepInEx 5 plus some fixed runtime files. The community Setup tool does it for you:
  https://github.com/swyf-modding/Setup   (Code > Download ZIP, extract it)
1. If you already did the normal Chaos Mode install, DELETE winhttp.dll and doorstop_config.ini from the game folder
   (the Setup tool leaves existing copies alone, and the old one points at the built-in loader).
2. Open PowerShell in the extracted Setup folder and run (put your own game folder in the quotes):
     powershell -ExecutionPolicy Bypass -File .\setup.ps1 -GameDir "C:\...\steamapps\common\Scam With Your Friends Playtest"
3. Re-run it after every game update.

INSTALL
1. Copy the BepInEx folder from here into the game folder (it merges with the one Setup made).
2. Copy the ChatBridge folder from the main ChaosMode folder into the game folder too, if you want chat votes
   from YouTube / TikTok / Kick or the OBS overlay.
3. Launch the game, host a FRIENDS ONLY or INVITE ONLY lobby and press F2.

NOTES
- Remove Mods\ChaosMode.dll if it's there, or you'll load Chaos Mode twice.
- Mods in the old "Mods" folder only load with the built-in loader, not with BepInEx.
- Logs: BepInEx\LogOutput.log and BepInEx\plugins\ChaosMode\ChaosMode.log
- Uninstall: delete BepInEx\plugins\ChaosMode. (Setup's own files are described in its README.)
