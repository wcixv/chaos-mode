CHAOS MODE for Scam With Your Friends (unofficial fan mod)
==========================================================

Chaos Mode runs on BepInEx. This game needs some fixed runtime files before BepInEx works, so there is a one-time setup.

SET UP BEPINEX (once)
1. Download the community Setup tool: https://github.com/swyf-modding/Setup  (Code > Download ZIP) and extract it.
2. Open PowerShell in that folder and run this, with YOUR game folder in the quotes:
     powershell -ExecutionPolicy Bypass -File .\setup.ps1 -GameDir "C:\...\steamapps\common\Scam With Your Friends Playtest"
3. Run it again after every game update.

Coming from v1.0? First delete winhttp.dll, doorstop_config.ini, the ModLoader folder and Mods\ChaosMode.dll from the game folder.
(The Setup tool leaves existing copies alone, and the old ones point at the v1.0 loader.)

INSTALL CHAOS MODE
1. In Steam, right-click Scam With Your Friends (Playtest) > Manage > Browse local files.
2. Copy the BepInEx folder from this zip into that game folder (it merges with the one Setup made).
3. Also copy the ChatBridge folder. Creator Mode (chat votes) stays locked until ChatBridge is installed.
4. Launch the game from Steam.

USE
- Host a FRIENDS ONLY or INVITE ONLY lobby (Chaos Mode is locked in public lobbies).
- Press F2 in game for the Chaos Mode menu.
- Your friends do NOT need to install anything.

CREATOR MODE (chat votes)
- F2 > turn on Creator Mode (needs the ChatBridge folder). Twitch works straight from the F2 menu.
- For YouTube / TikTok (via TikFinity) / Kick: open ChatBridge\ChatBridge.exe, fill in your channels, press START.
- OBS overlay: in ChatBridge click Copy, then in OBS add a Browser source with that URL (480 x 420).

TROUBLESHOOTING
- Tased / Launch / Knockout do nothing?  Turn OFF "Ragdoll Immunity" in the game settings.
- Windows warns about ChatBridge? Click "More info" > "Run anyway" (it's not code-signed).
- Broke after a game update? Run the Setup tool again.
- Logs: BepInEx\LogOutput.log and BepInEx\plugins\ChaosMode\ChaosMode.log
- Uninstall: delete BepInEx\plugins\ChaosMode.

Game updates can break mods. This mod isn't affiliated with the game's developers.
BepInEx and UnityDoorstop are LGPL-2.1 and come from the Setup tool.
