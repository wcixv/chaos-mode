CHAOS MODE for Scam With Your Friends (unofficial fan mod)
==========================================================

INSTALL
1. In Steam, right-click Scam With Your Friends (Playtest) > Manage > Browse local files.
2. Copy EVERYTHING in this folder EXCEPT the BepInEx-version folder into that game folder (winhttp.dll goes next to the game's .exe).
3. Launch the game from Steam.

USE
- Host a FRIENDS ONLY or INVITE ONLY lobby (Chaos Mode is locked in public lobbies).
- Press F2 in game for the Chaos Mode menu.
- Your friends do NOT need to install anything.

CREATOR MODE (chat votes)
- F2 > turn on Creator Mode. Twitch works straight from the F2 menu.
- For YouTube / TikTok (via TikFinity) / Kick: open ChatBridge\ChatBridge.exe, fill in your channels, press START.
- OBS overlay: in ChatBridge click Copy, then in OBS add a Browser source with that URL (480 x 420).

TROUBLESHOOTING
- Tased / Launch / Knockout do nothing?  Turn OFF "Ragdoll Immunity" in the game settings.
- Windows warns about ChatBridge? Click "More info" > "Run anyway" (it's not code-signed).
- Logs: ModLoader\ModLoader.log and Mods\ChaosMode.log
- Uninstall: delete winhttp.dll from the game folder.

USING OTHER MODS? (BepInEx)
- There is also a BepInEx version in the BepInEx-version folder. Read BepInEx-version\README.txt first. Most people should skip it.

Game updates can break mods. This mod isn't affiliated with the game's developers.
Uses UnityDoorstop (LGPL-2.1, https://github.com/NeighTools/UnityDoorstop).
